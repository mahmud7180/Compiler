 #include <bits/stdc++.h>
#include <fstream>
#include <sstream>
using namespace std;
int main()
{
    ofstream file;
    file.open("file.txt");
    string str;
    getline(cin, str);
    file << str;
    file.close();

    FILE *fp;
    fp = fopen("file.txt", "r+");
    ifstream input("file.txt");
    string ch;
    ofstream file1;
    file1.open("file1.txt");

    while (getline(input, ch, ' '))
    {

        if (ch == " " || ch == "," || ch == ";" || ch == ">" ||
            ch == "<" || ch == "(" || ch == ")" ||
            ch == "[" || ch == "]" || ch == "{" || ch == "}" || ch == "&" || ch == "!")
        {

            cout << ch << " is a Delimiter\n";
            file1 << ch << " is a Delimiter\n";
        }
        else if (ch == "+" || ch == "-" || ch == "*" ||
                 ch == "/" || ch == ">" || ch == "<" ||
                 ch == "=")
        {
            cout << ch << " is a Operator\n";
            file1 << ch << " is a Operator\n";
        }
        else if (ch == "0" || ch == "1" || ch == "2" ||
                 ch == "3" || ch == "4" || ch == "5" ||
                 ch == "6" || ch == "7" || ch == "8" || ch == "9")
        {
            cout << ch << " is a Number\n";
            file1 << ch << " is a Number\n";
        }
        else if (ch == "if" || ch == "else" || ch == "while" ||
                 ch == "double" || ch == "float" || ch == "5" ||
                 ch == "int" || ch == "for" || ch == "char" || ch == "static")

        {
            cout << ch << " is a Keyword\n";
            file1 << ch << " is a Keyword\n";
        }
        else
        {
            cout << ch << " is Variable\n";
            file1 << ch << " is a Variable\n";
        }
    }
    fclose(fp);
}
