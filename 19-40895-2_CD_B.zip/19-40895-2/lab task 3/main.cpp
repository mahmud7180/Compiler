 #include <iostream>
using namespace std;

int main()
{
    char string[100];
    cout << "Enter a string expression: ";
    cin >> string;

    int count = 0;
    int i = 0;

    while (string[i] != 0)
    {
        if (string[i] == '(')
        {
            count++;
        }

        else if (string[i] == ')')
        {
            count--;

            if (count < 0)
            {
                break;
            }
        }
        i++;
    }
    if (count == 0)
    {
        cout << "vaild expression string" << endl;
    }
    else
    {
        cout << "invalid expression string" << endl;
    }
}
